---
permalink: /teaching2/
title: "Teaching"
author_profile: true
redirect_from: 
 - /teaching2/
 - /teaching2.html
---

|      Date       |                            Course                            |
| :-------------: | :----------------------------------------------------------: |
|    2024.09~     |    Intellectual Property Economics and Management (HITSZ)    |
|    2024.09~     |      Trademark, Brand and Regional Economy (Guangdong)       |
|    2023.12~     | The Economics of Money, Banking and Financial Market (HITSZ) |
|    2023.11~     |         Money, Banking and Financial Market (HITSZ)          |
| 2021.03~2022.06 |      Chinese Economy: Transition and Upgrading (HITSZ)       |
|    2020.12 ~    |           Economic Geography of Innovation (HITSZ)           |
| 2020.06~2020.11 |                 Innovation Economics (HITSZ)                 |
| 2018.04~2018.05 | Text Mining of Patent data (Word Embedding, RNN, etc.) at UTokyo |
| 2012.03~2013.02 | Science, Technology and Society (National Innovation Policy, etc.) at PKU |
| 2012.09~2013.02 | History of Science and Technology (Scientific Revolution) at PKU |