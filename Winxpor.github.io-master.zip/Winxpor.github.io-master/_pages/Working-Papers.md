---
permalink: /Working-Papers/
title: "Working Papers"
author_profile: true
redirect_from: 
  - /Working-Papers/
  - /Working-Papers.html
---

## Working-in-progress

- **Deyun YIN**, Jie TANG, Tao JIANG, Zheng ZENG, Tong YIN, Zhao WU, **Measuring the Quality of Chinese Patents: Has China Realized Indigenous Innovation?**
- **Deyun YIN**, Zhao Wu, Tao Jiang. **Farewell to Counting the Number: A Complex Indicator for Measuring and Assessing Chinese Patents’ Quality.**
- Julio RAFFO, **Deyun YIN** & Alica DALY, **Impact of Artificial Intelligence on innovation: Evidence from Robotics.** WIPO Working Paper Series.
- **Deyun YIN**, Ernest MIGUELEZ. **Learn-by-hiring: Knowledge Sourcing of Domestic Firms in Emerging Markets** (Data processing finished)
- **Deyun YIN,** Julio RAFFO, **Unravelling the gender unbalance in innovation** 


